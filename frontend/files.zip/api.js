// ---- The only file that talks to the backend. ----
// Request  (POST {API_BASE_URL}/predict): { pressure, temperature, ..., sampling_method, mollusc_type, species }
// Response: { risk_label: "HIGH" | "LOW",
//             probabilities: { low: 0..1, high: 0..1 },
//             estimated_concentration_mg_kg: number | null }   // only filled for HIGH
import { CONFIG } from "./config.js";

export class BackendError extends Error {}

export async function predictRisk(payload) {
  let res;
  try {
    res = await fetch(CONFIG.API_BASE_URL + CONFIG.PREDICT_PATH, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new BackendError("Backend not connected. Start the FastAPI server and check API_BASE_URL in js/config.js.");
  }
  if (!res.ok) throw new BackendError(`Backend returned an error (HTTP ${res.status}).`);
  const data = await res.json();
  if (!data || !["HIGH", "LOW"].includes(String(data.risk_label).toUpperCase()) || !data.probabilities)
    throw new BackendError("Unexpected response format from /predict.");
  return data;
}

// Future: add getDatasetSummary() and getMetrics() here (e.g. GET /dataset/summary, GET /metrics).
